import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json, random, math, os, copy, zipfile, tempfile, shutil, sys, io
from pathlib import Path
from PIL import Image, ImageTk
from embedded_assets import ASSETS

WORLD_W, WORLD_H = 8000, 5000
TOOLS = [
    ('↖ Выбор','select'),('✋ Панорама','pan'),('🌊 Река','river'),('🛣 Дорога','road'),
    ('🌲 Лес','forest'),('🌳 Дерево','tree'),('🌾 Поле','field'),('⛰ Скалы','rock'),
    ('🏠 Дом','house'),('🗼 Башня','tower'),('🏰 Замок','keep'),('⛪ Церковь','church'),
    ('🧱 Ворота','gate'),('⚙ Мельница','mill'),('🐄 Амбар','barn'),('🌉 Мост','bridge'),
    ('🚚 Телега','wagon'),('☘ Куст','bush'),('✦ Сено','hay'),('⌫ Ластик','erase')]
TYPES=['Пехота','Стрелки','Конница','Осадные','Магия','Особое']
TRAINING=['Сброд','Новобранцы','Регулярные','Профессионалы','Ветераны','Живые мифы']
MORALE=['Полностью разбиты','Низкая мораль','Средняя мораль','Высокая мораль','Преданные','Фанатики','За гранью безумия']
WEAPONS=['Древковое оружие','Одноручное клинковое','Двуручное клинковое','Ударно-дробящее','Лёгкое дистанционное','Тяжёлое дистанционное','Огнестрельное']
ARMOR=['Стеганая броня','Вареная кожа','Чешуйчатый доспех','Кольчуга','Бригантина','Полулаты','Полные латы']
SIEGE=['Баллиста','Таран','Катапульта','Требушет','Осадная башня','Бомбарда','Мортира']
LABELS=dict(TOOLS)

class App:
    def __init__(self,root):
        self.root=root;root.title('Medieval Battlefield Editor v4');root.geometry('1650x1000');root.minsize(1280,760)
        self.scale=.55;self.pan_x=self.pan_y=0;self.tool='select';self.brush=150
        self.seed=random.randrange(1,2**31-1);self.objects=[];self.units=[];self.selected=None
        self.oid_n=0;self.uid_n=0;self.stroke=None;self.pan=None;self.last=None;self.drag=False
        self.undo_stack=[];self.redo_stack=[];self.tkimg={};self.sprite_cache={};self.asset_pil_cache={};self.project_tmp=None
        self._render_pending=False;self._render_after=None;self._render_revision=0
        self.make_ui();self.generate()
    def oid(self):self.oid_n+=1;return f'O{self.oid_n}'
    def uid(self):self.uid_n+=1;return f'U{self.uid_n}'
    def make_ui(self):
        style=ttk.Style();
        try:style.theme_use('clam')
        except:pass
        top=ttk.Frame(self.root);top.pack(fill='x',padx=6,pady=6)
        for t,fn in [('🎲 Новая карта',self.generate),('↶ Undo',self.undo),('↷ Redo',self.redo),('💾 JSON',self.save_json),('📦 Проект',self.save_project),('📂 Открыть',self.load_project)]:ttk.Button(top,text=t,command=fn).pack(side='left',padx=2)
        ttk.Separator(top,orient='vertical').pack(side='left',fill='y',padx=7)
        ttk.Button(top,text='＋ Подразделение',command=self.add_unit).pack(side='left',padx=2)
        ttk.Button(top,text='🖼 Картинка юнита',command=lambda:self.import_unit_image()).pack(side='left',padx=2)
        ttk.Button(top,text='⚔ Расчёт боя',command=self.battle).pack(side='left',padx=2)
        ttk.Label(top,text='Название:').pack(side='left',padx=(15,3));self.name=tk.StringVar(value='Новая карта');ttk.Entry(top,textvariable=self.name,width=24).pack(side='left')
        body=ttk.Frame(self.root);body.pack(fill='both',expand=True,padx=6)
        left=ttk.Frame(body,width=205);left.pack(side='left',fill='y',padx=(0,6));left.pack_propagate(False)
        lf=ttk.LabelFrame(left,text='Инструменты');lf.pack(fill='x')
        for text,k in TOOLS:ttk.Button(lf,text=text,command=lambda k=k:self.set_tool(k)).pack(fill='x',padx=3,pady=1)
        vf=ttk.LabelFrame(left,text='Кисть и вид');vf.pack(fill='x',pady=6)
        self.brushvar=tk.IntVar(value=150);ttk.Scale(vf,from_=30,to=350,variable=self.brushvar,orient='horizontal',command=lambda _:self.brush_update()).pack(fill='x',padx=4);self.brushlabel=ttk.Label(vf,text='Размер: 150');self.brushlabel.pack()
        ttk.Button(vf,text='＋',command=lambda:self.zoom(1.12)).pack(side='left',expand=True,padx=2);ttk.Button(vf,text='−',command=lambda:self.zoom(.89)).pack(side='left',expand=True,padx=2);ttk.Button(vf,text='Сброс',command=self.reset_view).pack(side='left',expand=True,padx=2);ttk.Button(vf,text='🗺 8000×5000',command=lambda:self.set_map_size(8000,5000)).pack(fill='x',padx=3,pady=3)
        ttk.Button(vf,text='Очистить природный слой',command=self.clear_nature).pack(fill='x',padx=3,pady=3)
        ttk.Label(left,text='ЛКМ: выбор/рисование\nСКМ: панорама\nКолесо: масштаб\nЛастик: зажмите ЛКМ и ведите\nShift+ЛКМ: не менять выбор').pack(padx=7,pady=5,anchor='w')
        center=ttk.Frame(body);center.pack(side='left',fill='both',expand=True)
        self.canvas=tk.Canvas(center,bg='#a99b74',highlightthickness=0);self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Button-1>',self.left);self.canvas.bind('<B1-Motion>',self.left_drag);self.canvas.bind('<ButtonRelease-1>',self.left_up);self.canvas.bind('<Button-2>',self.pan_start);self.canvas.bind('<B2-Motion>',self.pan_move);self.canvas.bind('<ButtonRelease-2>',lambda e:setattr(self,'pan',None));self.canvas.bind('<MouseWheel>',self.wheel);self.canvas.bind('<Button-4>',lambda e:self.zoom(1.1));self.canvas.bind('<Button-5>',lambda e:self.zoom(.9));self.canvas.bind('<Delete>',lambda e:self.delete_selected());self.canvas.focus_set()
        right=ttk.Frame(body,width=390);right.pack(side='right',fill='y',padx=(6,0));right.pack_propagate(False)
        self.palette=ttk.LabelFrame(right,text='Библиотека объектов');self.palette.pack(fill='x')
        self.palette_canvas=tk.Canvas(self.palette,height=260,highlightthickness=0);self.palette_canvas.pack(fill='x');self.palette_frame=ttk.Frame(self.palette_canvas);self.palette_canvas.create_window((0,0),window=self.palette_frame,anchor='nw');self.build_palette()
        self.props=ttk.LabelFrame(right,text='Свойства');self.props.pack(fill='x',pady=6)
        self.layers=ttk.LabelFrame(right,text='Объекты и подразделения');self.layers.pack(fill='both',expand=True)
        self.tree=ttk.Treeview(self.layers,columns=('kind','side','men'),show='headings');
        for c,t,w in [('kind','Объект',150),('side','Сторона',75),('men','Людей',65)]:self.tree.heading(c,text=t);self.tree.column(c,width=w)
        self.tree.pack(fill='both',expand=True,padx=3,pady=3);self.tree.bind('<<TreeviewSelect>>',self.tree_select)
        self.status=tk.StringVar(value='Готово');ttk.Label(self.root,textvariable=self.status,anchor='w').pack(fill='x',padx=8,pady=4)
        self.empty_props()
    def build_palette(self):
        groups={'buildings':[(p.stem,p) for p in Path('assets/buildings').glob('*.png')] if False else [],'terrain':[]}
        # Palette is populated from embedded assets, no external asset directory is required.
        for w in self.palette_frame.winfo_children():w.destroy()
        cats=[('Здания',['house_wood_01','house_wood_02','house_stone_01','house_stone_02','tower_01','keep_01','church_01','gate_01','mill_01','barn_01','barn_02']),('Природа',['tree_01','tree_02','tree_03','rock_01','rock_02','rock_03','field_01','field_02','field_03','bush_01','bush_02','bush_03']),('Декор',['wagon_01','hay_01'])]
        for title,names in cats:
            ttk.Label(self.palette_frame,text=title,font=('Arial',10,'bold')).pack(anchor='w',padx=4,pady=(4,1))
            row=ttk.Frame(self.palette_frame);row.pack(fill='x')
            for name in names:
                if not any(k.endswith(name+'.png') for k in ASSETS):continue
                b=ttk.Button(row,text=name.replace('_',' ').replace('01','1').replace('02','2').replace('03','3'),command=lambda n=name:self.place_asset(n));b.pack(side='left',padx=2,pady=2)
    def asset_key(self,name):
        for k in ASSETS:
            if k.endswith('/'+name+'.png'):return k
        return None
    def asset_pil(self,name):
        if name in self.asset_pil_cache:
            return self.asset_pil_cache[name]
        key=self.asset_key(name)
        if not key:return None
        try:
            im=Image.open(io.BytesIO(__import__('base64').b64decode(ASSETS[key]))).convert('RGBA')
            self.asset_pil_cache[name]=im
            return im
        except Exception:
            return None
    def place_asset(self,name):
        self.set_tool('asset');self.pending_asset=name;self.status.set('Выберите место для: '+name)
    def brush_update(self):self.brush=int(self.brushvar.get());self.brushlabel.config(text=f'Размер: {self.brush}')
    def set_tool(self,k):self.tool=k;self.status.set('Инструмент: '+LABELS.get(k,k));self.canvas.configure(cursor='hand2' if k in ('select','pan') else 'crosshair')
    def world_to_screen(self,x,y):return ((x-WORLD_W/2)*self.scale+self.canvas.winfo_width()/2+self.pan_x,(y-WORLD_H/2)*self.scale+self.canvas.winfo_height()/2+self.pan_y)
    def screen_to_world(self,x,y):return ((x-self.canvas.winfo_width()/2-self.pan_x)/self.scale+WORLD_W/2,(y-self.canvas.winfo_height()/2-self.pan_y)/self.scale+WORLD_H/2)
    def snap(self,x,y):return (max(0,min(WORLD_W,x)),max(0,min(WORLD_H,y)))
    def snapshot(self):
        self.undo_stack.append(json.dumps({'objects':self.objects,'units':self.units},ensure_ascii=False));self.undo_stack=self.undo_stack[-40:];self.redo_stack=[]
    def undo(self):
        if not self.undo_stack:return
        self.redo_stack.append(json.dumps({'objects':self.objects,'units':self.units},ensure_ascii=False));self.restore_state(self.undo_stack.pop())
    def redo(self):
        if not self.redo_stack:return
        self.undo_stack.append(json.dumps({'objects':self.objects,'units':self.units},ensure_ascii=False));self.restore_state(self.redo_stack.pop())
    def restore_state(self,s):
        d=json.loads(s);self.objects=d['objects'];self.units=d['units'];self.selected=None;self.tkimg.clear();self.sprite_cache.clear();self.render();self.refresh();self.empty_props()
    def generate(self):
        if self.objects or self.units:self.snapshot()
        r=random.Random(random.randrange(1,2**31-1));self.seed=r.randrange(1,2**31-1);self.objects=[];self.units=[];self.selected=None;self.oid_n=self.uid_n=0
        self.name.set(r.choice(['Битва у Старого Брода','Долина Вязов','Сражение за Каменный мост','Дубовая долина','Осада Речной крепости']))
        # river network
        y=r.randint(500,1500);main=[]
        for x in range(-200,WORLD_W+250,180):y=max(100,min(WORLD_H-100,y+r.randint(-170,170)));main.append((x,y))
        self.objects.append({'id':self.oid(),'kind':'river','points':main,'width':r.randint(85,135)})
        for _ in range(r.randint(1,2)):
            sx=r.randint(500,7000);ey=r.randint(500,4200);p=[(sx,-100)];x=sx
            for yy in range(80,ey,150):x+=r.randint(-220,220);p.append((x,yy))
            p.append((x,ey));self.objects.append({'id':self.oid(),'kind':'river','points':p,'width':r.randint(45,80)})
        # terrain masses
        for _ in range(r.randint(9,15)):self.add_nature(r,'forest')
        for _ in range(r.randint(7,12)):self.add_nature(r,'field')
        for _ in range(r.randint(5,9)):self.add_nature(r,'rock')
        # roads between hubs
        hubs=[(r.randint(600,7400),r.randint(500,4300)) for _ in range(7)]
        for i in range(len(hubs)-1):
            a,b=hubs[i],hubs[i+1];m=((a[0]+b[0])/2+r.randint(-180,180),(a[1]+b[1])/2+r.randint(-180,180));self.objects.append({'id':self.oid(),'kind':'road','points':[a,m,b],'width':30})
        cx,cy=r.randint(1800,6200),r.randint(1400,3600);self.objects.append({'id':self.oid(),'kind':'settlement','x':cx,'y':cy,'name':r.choice(['Вязовая','Старый Брод','Дубравка','Каменный Холм'])})
        occupied=[]
        assets=['house_wood_01','house_wood_02','house_stone_01','barn_01','mill_01']
        for _ in range(r.randint(18,28)):
            for attempt in range(40):
                a=r.random()*math.tau;rad=r.randint(130,430);x=cx+math.cos(a)*rad;y=cy+math.sin(a)*rad
                if all((x-qx)**2+(y-qy)**2>75**2 for qx,qy in occupied):break
            occupied.append((x,y));self.objects.append({'id':self.oid(),'kind':'asset','asset':r.choice(assets),'x':x,'y':y,'size':r.randint(75,115)})
        self.objects += [{'id':self.oid(),'kind':'asset','asset':'keep_01','x':cx,'y':cy-40,'size':135},{'id':self.oid(),'kind':'asset','asset':'church_01','x':cx-160,'y':cy+80,'size':100},{'id':self.oid(),'kind':'bridge','x':cx+480,'y':cy,'length':180}]
        self.render();self.refresh();self.status.set(f'Карта полностью пересобрана • seed {self.seed}')
    def add_nature(self,r,kind):
        if kind=='forest':o={'id':self.oid(),'kind':'asset','asset':r.choice(['bush_01','bush_02','bush_03']),'x':r.randint(120,WORLD_W-120),'y':r.randint(120,WORLD_H-120),'size':r.randint(180,320)}
        elif kind=='field':o={'id':self.oid(),'kind':'asset','asset':r.choice(['field_01','field_02','field_03']),'x':r.randint(120,WORLD_W-120),'y':r.randint(120,WORLD_H-120),'size':r.randint(160,300)}
        else:o={'id':self.oid(),'kind':'asset','asset':r.choice(['rock_01','rock_02','rock_03']),'x':r.randint(100,WORLD_W-100),'y':r.randint(100,WORLD_H-100),'size':r.randint(100,230)}
        self.objects.append(o)
    def _visible_world_rect(self, margin=300):
        w=max(1,self.canvas.winfo_width()); h=max(1,self.canvas.winfo_height())
        x0,y0=self.screen_to_world(0,0); x1,y1=self.screen_to_world(w,h)
        return (min(x0,x1)-margin,min(y0,y1)-margin,max(x0,x1)+margin,max(y0,y1)+margin)

    def _bbox_visible(self, o, rect):
        x0,y0,x1,y1=rect
        if o.get('kind') in ('river','road'):
            pts=o.get('points',[])
            if not pts:return False
            bx0=min(p[0] for p in pts)-o.get('width',25)*2
            by0=min(p[1] for p in pts)-o.get('width',25)*2
            bx1=max(p[0] for p in pts)+o.get('width',25)*2
            by1=max(p[1] for p in pts)+o.get('width',25)*2
            return not (bx1<x0 or bx0>x1 or by1<y0 or by0>y1)
        if 'x' not in o:return True
        r=max(80,o.get('size',100)/2,o.get('length',160)/2)
        return not (o['x']+r<x0 or o['x']-r>x1 or o['y']+r<y0 or o['y']-r>y1)

    def render(self):
        # Coalesce repeated render requests during mouse movement.
        self._render_revision += 1
        self.canvas.delete('all')
        w=max(1,self.canvas.winfo_width());h=max(1,self.canvas.winfo_height())
        self.canvas.create_rectangle(0,0,w,h,fill='#b8a97c',outline='',tags='background')

        rect=self._visible_world_rect()
        # Draw only objects intersecting the current viewport.
        for o in self.objects:
            if o['kind'] in ('river','road') and self._bbox_visible(o,rect):
                self.draw_line_obj(o)
        for o in self.objects:
            if o['kind'] not in ('river','road') and self._bbox_visible(o,rect):
                self.draw_obj(o)
        for u in self.units:
            if rect[0]-100 <= u['x'] <= rect[2]+100 and rect[1]-100 <= u['y'] <= rect[3]+100:
                self.draw_unit(u)
        if self.selected:
            self.draw_selection(self.selected[1])

    def pts(self,p):return [v for x,y in p for v in self.world_to_screen(x,y)]
    def draw_line_obj(self,o):
        p=self.pts(o['points']);wd=o.get('width',25)*self.scale
        if o['kind']=='river':
            self.canvas.create_line(*p,fill='#4b4238',width=max(8,int(wd+32*self.scale)),smooth=True,capstyle='round');self.canvas.create_line(*p,fill='#4fa8a2',width=max(5,int(wd)),smooth=True,capstyle='round');self.canvas.create_line(*p,fill='#8ccbc1',width=max(1,int(3*self.scale)),smooth=True)
        else:
            self.canvas.create_line(*p,fill='#624b37',width=max(5,int(wd+11*self.scale)),smooth=True,capstyle='round');self.canvas.create_line(*p,fill='#d1b98b',width=max(3,int(wd)),smooth=True,capstyle='round')
    def draw_obj(self,o):
        if o['kind']=='bridge':
            x,y=self.world_to_screen(o['x'],o['y']);L=o.get('length',160)*self.scale;self.canvas.create_rectangle(x-L/2,y-12*self.scale,x+L/2,y+12*self.scale,fill='#68462e',outline='#302117',width=3)
            for xx in range(int(x-L/2+8),int(x+L/2),max(8,int(18*self.scale))):self.canvas.create_line(xx,y-11*self.scale,xx,y+11*self.scale,fill='#b17c47',width=2)
        elif o['kind']=='settlement':
            x,y=self.world_to_screen(o['x'],o['y']);self.canvas.create_oval(x-520*self.scale,y-400*self.scale,x+520*self.scale,y+400*self.scale,outline='#655039',dash=(8,5),width=2);self.canvas.create_text(x,y-420*self.scale,text=o.get('name','Поселение'),font=('Georgia',max(9,int(18*self.scale)),'bold'),fill='#38291e')
        elif o['kind']=='asset':self.draw_asset(o)
        elif o['kind']=='tree':self.draw_asset({'asset':o['asset'],'x':o['x'],'y':o['y'],'size':o.get('size',70)})
    def draw_asset(self,o):
        im=self.asset_pil(o['asset'])
        if im is None:return
        x,y=self.world_to_screen(o['x'],o['y'])
        # Cap the rasterized sprite size to keep zooming responsive.
        target=max(8,min(1200,int(o.get('size',100)*self.scale)))
        key=(o['asset'],target)
        if key not in self.sprite_cache:
            ratio=min(target/im.width,target/im.height)
            res=im.resize((max(1,int(im.width*ratio)),max(1,int(im.height*ratio))),Image.Resampling.LANCZOS)
            self.sprite_cache[key]=ImageTk.PhotoImage(res)
        self.canvas.create_image(x,y,image=self.sprite_cache[key],tags=('obj',o['id']))

    def draw_unit(self,u):
        x,y=self.world_to_screen(u['x'],u['y']);img=self.unit_img(u)
        if img:self.canvas.create_image(x,y,image=img,tags=('unit',u['id']))
        else:
            c='#a72f2f' if u['side']=='Красные' else '#315f99';w=30*self.scale;h=19*self.scale;self.canvas.create_rectangle(x-w,y-h,x+w,y+h,fill=c,outline='#201813',width=2,tags=('unit',u['id']));self.canvas.create_text(x,y,text=u['id'],fill='white',font=('Arial',max(7,int(9*self.scale)),'bold'))
        self.canvas.create_text(x,y+34*self.scale,text=u['name'],font=('Georgia',max(7,int(10*self.scale))),fill='#2c2118')
    def unit_img(self,u):
        p=u.get('image');
        if not p or not os.path.exists(p):return None
        key=(p,int(u.get('image_size',100)*self.scale))
        if key in self.tkimg:return self.tkimg[key]
        try:
            im=Image.open(p).convert('RGBA');target=max(20,key[1]);ratio=min(target/im.width,target/im.height);im=im.resize((max(1,int(im.width*ratio)),max(1,int(im.height*ratio))),Image.Resampling.LANCZOS);q=ImageTk.PhotoImage(im);self.tkimg[key]=q;return q
        except:return None
    def draw_selection(self,o):
        if 'x' not in o:return
        x,y=self.world_to_screen(o['x'],o['y']);s=o.get('size',100)*self.scale/2+12;self.canvas.create_rectangle(x-s,y-s,x+s,y+s,outline='#f2d27b',dash=(6,4),width=2,tags='selection')
    def pick(self,sx,sy):
        x,y=self.screen_to_world(sx,sy)
        for u in reversed(self.units):
            if abs(x-u['x'])<90 and abs(y-u['y'])<80:return ('unit',u)
        for o in reversed(self.objects):
            if 'x' in o and abs(x-o['x'])<max(80,o.get('size',100)/2) and abs(y-o['y'])<max(70,o.get('size',100)/2):return ('object',o)
            if o['kind'] in ('river','road'):
                for a,b in zip(o['points'],o['points'][1:]):
                    if self.segdist((x,y),a,b)<o.get('width',25)*1.5:return ('object',o)
        return None
    def segdist(self,p,a,b):
        x,y=p;x1,y1=a;x2,y2=b;dx=x2-x1;dy=y2-y1
        if dx==dy==0:return math.hypot(x-x1,y-y1)
        t=max(0,min(1,((x-x1)*dx+(y-y1)*dy)/(dx*dx+dy*dy)));return math.hypot(x-(x1+t*dx),y-(y1+t*dy))
    def left(self,e):
        self.canvas.focus_set();x,y=self.snap(*self.screen_to_world(e.x,e.y))
        if self.tool=='pan':self.pan_start(e);return
        if self.tool=='select':
            self.selected=self.pick(e.x,e.y);self.show_props() if self.selected else self.empty_props();self.render();return
        if self.tool=='asset':self.snapshot();self.objects.append({'id':self.oid(),'kind':'asset','asset':self.pending_asset,'x':x,'y':y,'size':100});self.selected=('object',self.objects[-1]);self.show_props();self.render();self.refresh();return
        if self.tool=='erase':
            self.snapshot()
            self._erase_at(x,y)
            return
        if self.tool in ('river','road'):
            self.snapshot();self.stroke=[(x,y)];return
        self.snapshot();self.paint(self.tool,x,y)
    def left_drag(self,e):
        x,y=self.snap(*self.screen_to_world(e.x,e.y))
        if self.tool=='pan':self.pan_move(e);return
        if self.tool=='erase':
            self._erase_at(x,y)
            self.last=(x,y)
            return
        if self.tool=='select' and self.selected:
            self.selected[1]['x']=x;self.selected[1]['y']=y;self.render()
        elif self.tool in ('river','road') and self.stroke is not None:
            if math.hypot(x-self.stroke[-1][0],y-self.stroke[-1][1])>12:self.stroke.append((x,y));self.preview()
        elif self.tool in ('forest','tree'):
            if self.last is None or math.hypot(x-self.last[0],y-self.last[1])>self.brush*.5:self.paint(self.tool,x,y)
        self.last=(x,y)
    def _erase_at(self,x,y):
        # Continuous eraser: every drag event removes whatever is under the cursor.
        # For painted assets use the brush radius; for lines use hit-testing.
        radius=max(18,self.brush/2)
        removed=False
        for u in list(self.units):
            if math.hypot(x-u['x'],y-u['y']) <= max(radius,90):
                self.units.remove(u); removed=True
        for o in list(self.objects):
            hit=False
            if o.get('kind') in ('river','road'):
                hit=any(self.segdist((x,y),a,b) <= max(radius,o.get('width',25)*1.5)
                        for a,b in zip(o.get('points',[]),o.get('points',[])[1:]))
            elif 'x' in o:
                r=max(radius,o.get('size',100)/2,o.get('length',160)/2)
                hit=math.hypot(x-o['x'],y-o['y']) <= r
            if hit:
                self.objects.remove(o); removed=True
                if self.selected and self.selected[1] is o:self.selected=None
        if removed:
            self.empty_props()
            self.render()
            self.refresh()

    def left_up(self,e):
        if self.tool in ('river','road') and self.stroke and len(self.stroke)>1:
            self.objects.append({'id':self.oid(),'kind':self.tool,'points':self.stroke,'width':self.brush*.7 if self.tool=='river' else self.brush*.2});self.stroke=None;self.render();self.refresh()
        self.last=None
    def preview(self):
        self.render();
        if self.stroke:
            p=self.pts(self.stroke);self.canvas.create_line(*p,fill='#55aaa3' if self.tool=='river' else '#9e8055',width=max(3,int(self.brush*.5*self.scale)),smooth=True,capstyle='round',dash=(6,4))
    def paint(self,k,x,y):
        if k=='forest':name=random.choice(['bush_01','bush_02','bush_03']);size=random.randint(self.brush//2,self.brush);kind='asset'
        elif k=='tree':name=random.choice(['tree_01','tree_02','tree_03']);size=random.randint(60,95);kind='asset'
        elif k=='field':name=random.choice(['field_01','field_02','field_03']);size=random.randint(170,300);kind='asset'
        elif k=='rock':name=random.choice(['rock_01','rock_02','rock_03']);size=random.randint(100,220);kind='asset'
        elif k in ('house','tower','keep','church','gate','mill','barn'):
            name={'house':random.choice(['house_wood_01','house_wood_02','house_stone_01','house_stone_02']),'tower':'tower_01','keep':'keep_01','church':'church_01','gate':'gate_01','mill':'mill_01','barn':random.choice(['barn_01','barn_02'])}[k];size={'house':100,'tower':110,'keep':145,'church':120,'gate':125,'mill':120,'barn':115}[k];kind='asset'
        elif k=='wagon':name='wagon_01';size=120;kind='asset'
        elif k=='bush':name=random.choice(['bush_01','bush_02','bush_03']);size=100;kind='asset'
        elif k=='hay':name='hay_01';size=100;kind='asset'
        elif k=='bridge':self.objects.append({'id':self.oid(),'kind':'bridge','x':x,'y':y,'length':180});self.render();self.refresh();return
        else:return
        o={'id':self.oid(),'kind':kind,'asset':name,'x':x,'y':y,'size':size};self.objects.append(o);self.selected=('object',o);self.render();self.refresh()
    def pan_start(self,e):self.pan=(e.x,e.y,self.pan_x,self.pan_y)
    def pan_move(self,e):
        if self.pan:
            sx,sy,px,py=self.pan;self.pan_x=px+e.x-sx;self.pan_y=py+e.y-sy;self.render()
    def wheel(self,e):
        # Zoom around the mouse pointer instead of the map center.
        factor=1.12 if e.delta>0 or getattr(e,'num',0)==4 else 0.89
        before=self.screen_to_world(e.x,e.y)
        self.scale=max(.08,min(6.0,self.scale*factor))
        after=self.screen_to_world(e.x,e.y)
        self.pan_x += (after[0]-before[0])*self.scale
        self.pan_y += (after[1]-before[1])*self.scale
        self.tkimg.clear();self.sprite_cache.clear();self.render()

    def zoom(self,k,center=None):
        if center is None:
            cx=self.canvas.winfo_width()/2;cy=self.canvas.winfo_height()/2
        else:cx,cy=center
        before=self.screen_to_world(cx,cy)
        self.scale=max(.08,min(6.0,self.scale*k))
        after=self.screen_to_world(cx,cy)
        self.pan_x += (after[0]-before[0])*self.scale
        self.pan_y += (after[1]-before[1])*self.scale
        self.tkimg.clear();self.sprite_cache.clear();self.render()

    def reset_view(self):self.scale=.55;self.pan_x=self.pan_y=0;self.render()
    def set_map_size(self,w,h):
        global WORLD_W,WORLD_H
        WORLD_W,WORLD_H=int(w),int(h)
        self.generate()
        self.status.set(f'Размер карты: {WORLD_W} × {WORLD_H}')

    def clear_nature(self):self.snapshot();self.objects=[o for o in self.objects if o['kind'] not in ('asset',) or o.get('asset') in ('keep_01','church_01','gate_01','house_stone_01','house_wood_01','house_wood_02','house_stone_02','barn_01','barn_02','mill_01')];self.render();self.refresh()
    def remove(self,h):
        if not h:return
        k,o=h;arr=self.units if k=='unit' else self.objects
        if o in arr:arr.remove(o)
        self.selected=None;self.empty_props();self.render();self.refresh()
    def delete_selected(self):
        if self.selected:self.snapshot();self.remove(self.selected)
    def empty_props(self):
        for w in self.props.winfo_children():w.destroy()
        ttk.Label(self.props,text='Выберите объект или подразделение.').pack(padx=12,pady=16)
    def field(self,label,val,cb):
        f=ttk.Frame(self.props);f.pack(fill='x',padx=4,pady=2);ttk.Label(f,text=label,width=13).pack(side='left');v=tk.StringVar(value=str(val));e=ttk.Entry(f,textvariable=v);e.pack(side='left',fill='x',expand=True);e.bind('<Return>',lambda ev:cb(v.get()));e.bind('<FocusOut>',lambda ev:cb(v.get()))
    def combo(self,label,vals,val,cb):
        f=ttk.Frame(self.props);f.pack(fill='x',padx=4,pady=2);ttk.Label(f,text=label,width=13).pack(side='left');v=tk.StringVar(value=val);c=ttk.Combobox(f,textvariable=v,values=vals,state='readonly');c.pack(side='left',fill='x',expand=True);c.bind('<<ComboboxSelected>>',lambda ev:cb(v.get()))
    def num(self,o,k,v):
        try:o[k]=float(v) if '.' in str(v) else int(v)
        except:return
        self.render();self.refresh()
    def val(self,o,k,v):o[k]=v;self.render();self.refresh()
    def show_props(self):
        for w in self.props.winfo_children():w.destroy()
        if not self.selected:return
        k,o=self.selected
        if k=='unit':self.unit_props(o)
        else:
            self.field('ID',o['id'],lambda v:None)
            if 'x' in o:self.field('X',round(o['x']),lambda v:self.num(o,'x',v));self.field('Y',round(o['y']),lambda v:self.num(o,'y',v))
            if o.get('kind')=='asset':self.field('Размер',o.get('size',100),lambda v:self.num(o,'size',v));self.field('Спрайт',o.get('asset',''),lambda v:self.val(o,'asset',v))
            if o.get('kind')=='settlement':self.field('Название',o.get('name',''),lambda v:self.val(o,'name',v))
            if o.get('kind')=='bridge':self.field('Длина',o.get('length',180),lambda v:self.num(o,'length',v))
            if o.get('kind') in ('river','road'):self.field('Толщина',round(o.get('width',25)),lambda v:self.num(o,'width',v))
            ttk.Button(self.props,text='Удалить',command=self.delete_selected).pack(fill='x',padx=4,pady=5)
    def unit_props(self,u):
        for lab,val,cb in [('Название',u['name'],lambda v:self.val(u,'name',v)),('Людей',u['men'],lambda v:self.num(u,'men',v)),('Стоимость',u['cost'],lambda v:self.num(u,'cost',v)),('X',round(u['x']),lambda v:self.num(u,'x',v)),('Y',round(u['y']),lambda v:self.num(u,'y',v))]:self.field(lab,val,cb)
        self.combo('Сторона',['Красные','Синие'],u['side'],lambda v:self.val(u,'side',v));self.combo('Тип',TYPES,u['type'],lambda v:self.val(u,'type',v));self.combo('Обученность',TRAINING,u['training'],lambda v:self.val(u,'training',v));self.combo('Мораль',MORALE,u['morale'],lambda v:self.val(u,'morale',v));self.combo('Оружие',WEAPONS,u['weapon'],lambda v:self.val(u,'weapon',v));self.combo('Броня',ARMOR,u['armor'],lambda v:self.val(u,'armor',v))
        if u['type']=='Осадные':self.combo('Орудие',SIEGE,u.get('siege','Баллиста'),lambda v:self.val(u,'siege',v))
        ttk.Button(self.props,text='🖼 Выбрать картинку',command=lambda:self.import_unit_image(u)).pack(fill='x',padx=4,pady=2)
        if u.get('image'):self.field('Размер картинки',u.get('image_size',110),lambda v:self.num(u,'image_size',v));ttk.Button(self.props,text='Убрать картинку',command=lambda:self.remove_image(u)).pack(fill='x',padx=4,pady=2)
        ttk.Button(self.props,text='Клонировать',command=lambda:self.clone_unit(u)).pack(fill='x',padx=4,pady=2);ttk.Button(self.props,text='Удалить',command=self.delete_selected).pack(fill='x',padx=4,pady=2)
    def add_unit(self):
        self.snapshot();u={'id':self.uid(),'name':f'Подразделение {self.uid_n}','side':'Красные','type':'Пехота','men':100,'training':'Регулярные','morale':'Высокая мораль','weapon':'Древковое оружие','armor':'Кольчуга','cost':1000,'x':500+self.uid_n*70,'y':500};self.units.append(u);self.selected=('unit',u);self.show_props();self.render();self.refresh()
    def clone_unit(self,u):
        self.snapshot();n=copy.deepcopy(u);n['id']=self.uid();n['name']=u['name']+' (копия)';n['x']+=80;n['y']+=50;self.units.append(n);self.selected=('unit',n);self.show_props();self.render();self.refresh()
    def import_unit_image(self,u=None):
        if u is None:
            if not self.selected or self.selected[0]!='unit':self.add_unit()
            u=self.selected[1]
        p=filedialog.askopenfilename(filetypes=[('Изображения','*.png *.webp *.jpg *.jpeg *.bmp *.gif'),('Все файлы','*.*')])
        if not p:return
        self.snapshot();u['image']=os.path.abspath(p);u['image_size']=110;self.tkimg.clear();self.selected=('unit',u);self.show_props();self.render();self.status.set('Изображение подключено без изменения исходного файла.')
    def remove_image(self,u):self.snapshot();u.pop('image',None);u.pop('image_size',None);self.tkimg.clear();self.show_props();self.render()
    def refresh(self):
        for x in self.tree.get_children():self.tree.delete(x)
        names={'asset':'Спрайт','river':'🌊 Река','road':'🛣 Дорога','bridge':'🌉 Мост','settlement':'🏘 Поселение'}
        for o in self.objects:self.tree.insert('','end',iid=o['id'],values=(names.get(o['kind'],o.get('asset',o['kind'])),'',''))
        for u in self.units:self.tree.insert('','end',iid=u['id'],values=(u['name'],u['side'],u['men']))
    def tree_select(self,e):
        ids=self.tree.selection();
        if not ids:return
        i=ids[0];u=next((q for q in self.units if q['id']==i),None);o=next((q for q in self.objects if q['id']==i),None);self.selected=('unit',u) if u else ('object',o) if o else None;self.show_props();self.render()
    def serial(self):return {'version':5,'name':self.name.get(),'seed':self.seed,'objects':self.objects,'units':self.units}
    def save_json(self):
        p=filedialog.asksaveasfilename(defaultextension='.json',filetypes=[('JSON','*.json')]);
        if p:Path(p).write_text(json.dumps(self.serial(),ensure_ascii=False,indent=2),encoding='utf-8');self.status.set('JSON сохранён')
    def save_project(self):
        p=filedialog.asksaveasfilename(defaultextension='.mbp',filetypes=[('Medieval Battlefield Project','*.mbp')]);
        if not p:return
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);(td/'assets').mkdir();d=self.serial()
            for u in d['units']:
                if u.get('image') and os.path.exists(u['image']):dest=td/'assets'/(u['id']+Path(u['image']).suffix.lower());shutil.copy2(u['image'],dest);u['image']=str(Path('assets')/dest.name)
            (td/'map.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
            with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
                for f in td.rglob('*'):
                    if f.is_file():z.write(f,f.relative_to(td))
        self.status.set('Проект сохранён; изображения встроены в .mbp')
    def load_project(self):
        p=filedialog.askopenfilename(filetypes=[('Проект/JSON','*.mbp *.json')]);
        if not p:return
        try:
            if p.lower().endswith('.mbp'):
                td=Path(tempfile.mkdtemp(prefix='mbp_'));self.project_tmp=str(td)
                with zipfile.ZipFile(p) as z:z.extractall(td)
                d=json.loads((td/'map.json').read_text(encoding='utf-8'));base=td
            else:d=json.loads(Path(p).read_text(encoding='utf-8'));base=Path(p).parent
            for u in d.get('units',[]):
                if u.get('image') and not os.path.isabs(u['image']):u['image']=str(base/u['image'])
            self.name.set(d.get('name','Карта'));self.seed=d.get('seed',1);self.objects=d.get('objects',[]);self.units=d.get('units',[]);self.oid_n=max([int(o['id'][1:]) for o in self.objects if o.get('id','').startswith('O') and o['id'][1:].isdigit()] or [0]);self.uid_n=max([int(u['id'][1:]) for u in self.units if u.get('id','').startswith('U') and u['id'][1:].isdigit()] or [0]);self.selected=None;self.tkimg.clear();self.sprite_cache.clear();self.empty_props();self.render();self.refresh();self.status.set('Проект загружен')
        except Exception as e:messagebox.showerror('Ошибка загрузки',str(e))
    def battle(self):
        if len(self.units)<2:messagebox.showinfo('Бой','Добавьте минимум два подразделения.');return
        w=tk.Toplevel(self.root);w.title('Расчёт боя');w.geometry('470x350');names=[f"{u['id']} — {u['name']}" for u in self.units];a=tk.StringVar();b=tk.StringVar();ttk.Label(w,text='Атакующий').pack(pady=(15,3));ttk.Combobox(w,textvariable=a,values=names,state='readonly').pack(fill='x',padx=20);ttk.Label(w,text='Защитник').pack(pady=(10,3));ttk.Combobox(w,textvariable=b,values=names,state='readonly').pack(fill='x',padx=20)
        def fight():
            A=next((u for u in self.units if f"{u['id']} — {u['name']}"==a.get()),None);B=next((u for u in self.units if f"{u['id']} — {u['name']}"==b.get()),None)
            if not A or not B or A is B:return
            if A['side']==B['side']:messagebox.showwarning('Бой','Стороны должны различаться.');return
            self.snapshot();pa=1+TRAINING.index(A['training'])*.13+MORALE.index(A['morale'])*.07+ARMOR.index(A['armor'])*.08;pb=1+TRAINING.index(B['training'])*.13+MORALE.index(B['morale'])*.07+ARMOR.index(B['armor'])*.08;la=min(A['men'],max(1,round(B['men']*.055*pb/pa*random.uniform(.7,1.2))));lb=min(B['men'],max(1,round(A['men']*.055*pa/pb*random.uniform(.7,1.2))));A['men']-=la;B['men']-=lb;self.render();self.refresh();messagebox.showinfo('Результат боя',f"{A['name']}: −{la} человек\n{B['name']}: −{lb} человек\n\nМораль и состояние подразделений можно скорректировать в свойствах.");w.destroy()
        ttk.Button(w,text='⚔ Рассчитать',command=fight).pack(pady=25)

if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
