MEDIEVAL BATTLEFIELD EDITOR v4

Главная особенность v4: встроенная библиотека нарисованных средневековых объектов.
Никаких отдельных файлов графики для работы редактора не требуется.

В редакторе:
- полная генерация новой карты с новым seed;
- реки и притоки;
- ручное рисование рек и дорог;
- леса, деревья, поля, скалы;
- библиотека домов, каменных домов, башен, замка, церкви, ворот, мельницы, амбаров;
- мосты, телеги, сено и кусты;
- размещение объектов мышью;
- выбор, перемещение, удаление и редактирование объектов;
- Undo/Redo;
- масштабирование и панорамирование;
- подразделения с характеристиками;
- PNG/WebP/JPG изображения вместо цветных маркеров;
- исходная картинка юнита не изменяется;
- сохранение проекта .mbp с копией исходных картинок юнитов;
- базовый расчёт боя.

СБОРКА WINDOWS:
1. Установить Python 3.10+.
2. Запустить build_windows.bat.
3. Получить dist\\MedievalBattlefieldEditor.exe.
4. Этот EXE можно копировать на другой Windows-компьютер без Python и Pillow.

Для конечного пользователя нужен только EXE.


v5 changes:
- world map enlarged to 8000 x 5000;
- zoom range 0.08x..6x and zoom is centered under the mouse cursor;
- viewport culling: off-screen objects are not redrawn;
- removed expensive per-frame random parchment dots;
- cached decoded source sprites;
- eraser works continuously while holding LMB and dragging;
- erase uses a brush radius and can remove units, assets, roads and rivers.
