@echo off
setlocal
cd /d "%~dp0"
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
py -m PyInstaller --noconfirm --clean --onefile --windowed --name MedievalBattlefieldEditor Medieval_Battlefield_Editor_v4.py
if errorlevel 1 (
  echo.
  echo Сборка не удалась.
  pause
  exit /b 1
)
echo.
echo ГОТОВО: dist\MedievalBattlefieldEditor.exe
echo Это один файл: Python, Pillow и графика уже внутри.
pause
